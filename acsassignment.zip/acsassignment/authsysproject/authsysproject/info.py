EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'sajandas@ismt.edu.np'
EMAIL_HOST_PASSWORD = 'sajandas'
EMAIL_PORT = 587